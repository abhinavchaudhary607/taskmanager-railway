# TaskForge — Team Task Manager

> Role-based project & task management for modern teams

**Live Demo:** [Deploy on Railway → see steps below]  
**Stack:** React (frontend) · Express + Prisma + PostgreSQL (backend)

---

## Features

| Feature | Admin | Member |
|---|---|---|
| Auth (Signup / Login / JWT) | ✅ | ✅ |
| View projects | All projects | Assigned only |
| Create / Edit / Delete projects | ✅ | ❌ |
| Create tasks | Any project | Own only |
| Edit tasks | Full access | Status only |
| Delete tasks | ✅ | ❌ |
| View all team members | ✅ | ❌ |
| Dashboard (overdue, progress) | ✅ | ✅ |

---

## Local Setup

### Prerequisites
- Node.js 18+
- PostgreSQL (or use Railway's managed PostgreSQL)

### 1 — Clone & install
```bash
git clone https://github.com/YOUR_USERNAME/taskforge.git
cd taskforge

# Frontend
cd client && npm install

# Backend
cd ../server && npm install
```

### 2 — Environment variables

**server/.env**
```
DATABASE_URL="postgresql://user:password@localhost:5432/taskforge"
JWT_SECRET="your-super-secret-key-here"
PORT=4000
FRONTEND_URL="http://localhost:5173"
```

**client/.env**
```
VITE_API_URL="http://localhost:4000/api"
```

### 3 — Database setup
```bash
cd server
npx prisma migrate dev --name init
npm run seed          # optional: loads demo data
```

### 4 — Run dev servers
```bash
# Terminal 1 — API
cd server && npm run dev

# Terminal 2 — Frontend
cd client && npm run dev
```

App available at `http://localhost:5173`

---

## API Reference

### Auth
| Method | Endpoint | Body | Auth |
|---|---|---|---|
| POST | `/api/auth/signup` | `{name, email, password}` | — |
| POST | `/api/auth/login` | `{email, password}` | — |

### Projects
| Method | Endpoint | Auth |
|---|---|---|
| GET | `/api/projects` | ✅ |
| POST | `/api/projects` | Admin |
| PATCH | `/api/projects/:id` | Admin |
| DELETE | `/api/projects/:id` | Admin |

### Tasks
| Method | Endpoint | Notes |
|---|---|---|
| GET | `/api/tasks?projectId=&status=` | Filtered by role |
| POST | `/api/tasks` | Members → self-assign only |
| PATCH | `/api/tasks/:id` | Members → status only |
| DELETE | `/api/tasks/:id` | Admin only |

### Users
| Method | Endpoint | Auth |
|---|---|---|
| GET | `/api/users` | Admin |

All protected endpoints require: `Authorization: Bearer <token>`

---

## Deploy on Railway

### Step 1 — Push to GitHub
```bash
git init && git add . && git commit -m "init"
git remote add origin https://github.com/YOUR_USERNAME/taskforge.git
git push -u origin main
```

### Step 2 — Create Railway project
1. Go to [railway.app](https://railway.app) → **New Project**
2. Choose **Deploy from GitHub repo**
3. Select your repo

### Step 3 — Add PostgreSQL
1. In your Railway project → **+ New** → **Database** → **PostgreSQL**
2. Railway auto-injects `DATABASE_URL` into your backend service

### Step 4 — Configure backend service
In Railway dashboard → your backend service → **Variables**:
```
JWT_SECRET=your-secret-here
FRONTEND_URL=https://your-frontend.up.railway.app
PORT=4000
```

Set **Start Command**:
```
npx prisma migrate deploy && node index.js
```

Set **Root Directory**: `server`

### Step 5 — Configure frontend service
1. **+ New** → **GitHub repo** (same repo)
2. Set **Root Directory**: `client`
3. Add variable:
```
VITE_API_URL=https://your-backend.up.railway.app/api
```
4. Set **Build Command**: `npm run build`
5. Set **Start Command**: `npx serve dist`

### Step 6 — Deploy
Railway auto-deploys on every push. Your app is live! 🚀

---

## Project Structure

```
taskforge/
├── client/                    # React frontend (Vite)
│   ├── src/
│   │   ├── App.jsx            # Main app (auth, routing, state)
│   │   ├── components/
│   │   │   ├── Dashboard.jsx
│   │   │   ├── ProjectsView.jsx
│   │   │   ├── ProjectDetail.jsx
│   │   │   ├── TasksView.jsx
│   │   │   ├── TeamView.jsx
│   │   │   └── modals/
│   │   └── api.js             # Axios API client
│   └── package.json
│
├── server/                    # Express backend
│   ├── index.js               # Entry point
│   ├── middleware/
│   │   └── auth.js            # JWT + role middleware
│   ├── routes/
│   │   ├── auth.js
│   │   ├── projects.js
│   │   ├── tasks.js
│   │   └── users.js
│   ├── prisma/
│   │   ├── schema.prisma      # DB schema
│   │   └── seed.js            # Demo data
│   └── package.json
│
└── README.md
```

---

## Database Schema

```
User ──< ProjectMember >── Project ──< Task
                                         │
                           User ─────────┘ (assignee)
```

---

## Demo Credentials

| Role | Email | Password |
|---|---|---|
| Admin | alice@dev.io | pass123 |
| Member | bob@dev.io | pass123 |
| Member | carol@dev.io | pass123 |

---

## Tech Stack

**Frontend:** React 18, Vite, React Router, Axios, Syne + JetBrains Mono fonts  
**Backend:** Express.js, Prisma ORM, PostgreSQL  
**Auth:** JWT (jsonwebtoken), bcryptjs  
**Deploy:** Railway (backend + frontend + DB in one project)

---

## Demo Video Script (2–5 min)

1. **(0:00)** Show live URL, explain the app
2. **(0:30)** Sign up as new user → lands on dashboard
3. **(1:00)** Log in as Admin (alice@dev.io) → show full dashboard
4. **(1:30)** Create a new project, add team members
5. **(2:00)** Create tasks, assign to different members
6. **(2:30)** Switch to Member account (bob@dev.io) → show restricted view
7. **(3:00)** Member updates task status → show it reflected on Admin dashboard
8. **(3:30)** Show overdue task highlighting, progress bars
9. **(4:00)** Show Team view (admin only)
10. **(4:30)** Show Railway dashboard — live deployment

---

*Built with TaskForge — © 2025*
